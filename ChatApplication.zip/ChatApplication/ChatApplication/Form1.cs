﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Net;
using System.Net.Sockets;

namespace ChatApplication
{
    public partial class Form1 : Form
    {

        Socket socket;
        EndPoint epYou, epFriend;

        public Form1()
        {
            //Initializes socket, port numbers and retrieves local IP address.
            InitializeComponent();
            socket = new Socket(AddressFamily.InterNetwork, SocketType.Dgram, ProtocolType.Udp);
            socket.SetSocketOption(SocketOptionLevel.Socket, SocketOptionName.ReuseAddress, true);
            txtLocalPort.Text = "82";
            txtFriendPort.Text = "82";
            txtLocalIP.Text = GetIP();
        }

        //Method for getting the local IP address.
        private string GetIP()
        {
            IPHostEntry host;
            host = Dns.GetHostEntry(Dns.GetHostName());

            foreach (IPAddress ip in host.AddressList)
            {
                if (ip.AddressFamily == AddressFamily.InterNetwork)
                {
                    return ip.ToString();
                }
            }
            return "IP not found.";
        }

        //Method for receiving and displaying remote "Friend" messages.
        private void MessageCallBack(IAsyncResult asyncResult)
        {
            try
            {
                int size = socket.EndReceiveFrom(asyncResult, ref epFriend);
                if (size > 0)
                {
                    //Byte array to hold message
                    byte[] receivedData = new byte[1500];
                    receivedData = (byte[])asyncResult.AsyncState;
          
                    //Encodes the bytes back into a string
                    ASCIIEncoding eEncoding = new ASCIIEncoding();
                    string receivedMessage = eEncoding.GetString(receivedData);

                    //Adds message to the output screen
                    lstMessage.Items.Add("Friend: " + receivedMessage);
                }

                //Array for holding bytes
                byte[] buffer = new byte[1500];
                //Activates the socket
                socket.BeginReceiveFrom(buffer, 0, buffer.Length, SocketFlags.None, ref epFriend, new AsyncCallback(MessageCallBack), buffer);
            }
            catch (Exception e)
            {
                MessageBox.Show(e.ToString());
            }
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            
        }

        //Method for setting up connection between two users using end points and socket.
        private void btnStart_Click(object sender, EventArgs e)
        {
            lstMessage.Visible = true;
            txtMessage.Visible = true;
            btnSend.Visible = true;
            btnExit.Visible = true;
            groupBox1.Visible = false;
            groupBox2.Visible = false;
            btnStart.Visible = false;

            try
            {
                //Sets up local end point and binds it to the socket.
                epYou = new IPEndPoint(IPAddress.Parse(txtLocalIP.Text), Convert.ToInt32(txtLocalPort.Text));
                socket.Bind(epYou);

                //Sets up remote end point and connects it to the socket.
                epFriend = new IPEndPoint(IPAddress.Parse(txtFriendIP.Text), Convert.ToInt32(txtFriendPort.Text));
                socket.Connect(epFriend);

                //Array to hold bytes
                byte[] buffer = new byte[1500];
                //Activates the socket
                socket.BeginReceiveFrom(buffer, 0, buffer.Length, SocketFlags.None, ref epFriend, new AsyncCallback(MessageCallBack), buffer);
                txtMessage.Focus();
            }

            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }
        }

        //Method for sending your messages.
        private void btnSend_Click(object sender, EventArgs e)
        {
            try
            {
                System.Text.ASCIIEncoding enc = new System.Text.ASCIIEncoding();
                //Array to hold message bytes
                byte[] msg = new byte[1500];

                //Encodes text into bytes.
                msg = enc.GetBytes(txtMessage.Text);

                //Sends bytes using the socket.
                socket.Send(msg);

                //Adds message to your screen.
                lstMessage.Items.Add("You: " + txtMessage.Text);

                //Clears message box.
                txtMessage.Clear();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }
        }

        //Closes the program.
        private void btnExit_Click(object sender, EventArgs e)
        {
            this.Close();
        }

    }
}
