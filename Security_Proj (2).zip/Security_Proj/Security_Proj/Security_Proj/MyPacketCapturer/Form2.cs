﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MyPacketCapturer
{
    public partial class Form2 : Form
    {
        public Form2()
        {
            InitializeComponent();
        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {
            
        }

        private void Form2_Load(object sender, EventArgs e)
        {
            
        }

        public void timer2_Tick(object sender, EventArgs e)
        {
            textBox2.AppendText(frmCapture.stringPackets);
            frmCapture.stringPackets = "";
            textBox2.Text =
                "Number of Captured Packets: \t\t" + (frmCapture.numPackets) + Environment.NewLine + Environment.NewLine
                + "Ether Type Protocols:" + Environment.NewLine + Environment.NewLine
                + "IPv4s: " + frmCapture.IPv4 + "\t\t Percentages: " + (((double)(frmCapture.IPv4) / frmCapture.numPackets).ToString("0.00%")) + Environment.NewLine
                + "ARPs: " + frmCapture.ARP + "    \t\t Percentages: " + (((double)(frmCapture.ARP) / frmCapture.numPackets).ToString("0.00%")) + Environment.NewLine
                + "IPv6s: " + frmCapture.IPv6 + "    \t\t Percentages: " + (((double)(frmCapture.IPv6) / frmCapture.numPackets).ToString("0.00%")) + Environment.NewLine
                + "Not Listed: " + frmCapture.unknown + "\t\t Percentages: " + (((double)(frmCapture.unknown) / frmCapture.numPackets).ToString("0.00%")) + Environment.NewLine +Environment.NewLine
                
                + "IP Protocols :" + Environment.NewLine + Environment.NewLine
                + "TCPs: " + frmCapture.tcp + "    \t Percentages: " + (((double)(frmCapture.tcp) / frmCapture.numPackets).ToString("0.00%")) + Environment.NewLine
                + "ICMPs: " + frmCapture.icmp + "\t Percentages: " + (((double)(frmCapture.icmp) / frmCapture.numPackets).ToString("0.00%")) + Environment.NewLine
                + "UDPs: " + frmCapture.udp + "\t Percentages: " + (((double)(frmCapture.udp) / frmCapture.numPackets).ToString("0.00%")) + Environment.NewLine
                + "Not Listed: " + frmCapture.etc + "\t Percentages: " + (((double)(frmCapture.etc) / frmCapture.numPackets).ToString("0.00%")) + Environment.NewLine;
            
        }

        private void clearCurrentStatsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            textBox2.Clear();
            frmCapture.numPackets = 0;
            frmCapture.IPv4 = 0;
            frmCapture.ARP = 0;
            frmCapture.unknown = 0;
            frmCapture.udp = 0;
            frmCapture.tcp = 0;
            frmCapture.icmp = 0;
            
        }
    }
}
