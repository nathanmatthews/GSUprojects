﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Windows.Forms.DataVisualization.Charting;
using PacketDotNet;
using SharpPcap;
using System.Net;
using System.Net.Sockets;

namespace MyPacketCapturer
{
    public partial class frmCapture : Form
    {

        CaptureDeviceList devices;   //List of devices for this computer
        public static ICaptureDevice device; //The device we will be using
        public static string stringPackets = ""; //Data that is captured
        public static string stringPackets1 = "";
        public static int numPackets = 1;
        public static int IPv4;
        public static int ARP;
        public static int IPv6;
        public static int unknown;
        public static int tcp;
        public static int icmp;
        public static int udp;
        public static int etc;


        public static string passingText;


        frmSend fSend;  //This will be our send form
        Form2 f2;
        


        //**********Default constructor
        public frmCapture()
        {
            InitializeComponent();
            
            //Get the list of devices
            devices = CaptureDeviceList.Instance;

            //Make sure that there is at least one device
            if (devices.Count < 1)
            {
                MessageBox.Show("No Capture Devices Found!!!");
                Application.Exit();
            }

            //Add the devices to the combo box
            foreach (ICaptureDevice dev in devices)
            {
                cmbDevices.Items.Add(dev.Description);
            }

            //Get the second device and display in combo box
            device = devices[0];
            cmbDevices.Text = device.Description;

            //Register our handler function to the 'packet arrival' event
            device.OnPacketArrival += new SharpPcap.PacketArrivalEventHandler(device_OnPacketArrival);

            //Open the device for capturing
            int readTimeoutMilliseconds = 1000;
            device.Open(DeviceMode.Promiscuous, readTimeoutMilliseconds);

        } //End frmCapture


        //********** Event handler when a packet arrives
        public static void device_OnPacketArrival(object sender, CaptureEventArgs packet)
        {
            numPackets++;

            //Put the packet number in the capture window
            stringPackets += "Packet Number: " + Convert.ToString(numPackets);
            stringPackets += Environment.NewLine;

            stringPackets +=  Convert.ToInt32(numPackets);

            //Array to store our data
            byte[] data = packet.Packet.Data;

            //Keep track of the number of bytes displayed per line
            int byteCounter = 0;

            stringPackets += Environment.NewLine;
            stringPackets += "Destination MAC Address: ";
            //Parsing the packets
            foreach (byte b in data)
            {
                //Add the byte to our string (in hexidecimal)
                if (byteCounter <= 13) stringPackets += b.ToString("X2") + " ";
                byteCounter++;

                switch (byteCounter)
                {
                    case 6: stringPackets += Environment.NewLine;
                        stringPackets += "Source MAC Address: ";
                        break;
                    case 12: stringPackets += Environment.NewLine;
                        stringPackets += "EtherType: ";
                        break;

                    //Check ether type
                    case 14: if (data[12] == 8)
                        {
                            if (data[13] == 0)
                            {
                                stringPackets += "(IPv4)";
                                IPv4++;
                            }

                            else if (data[13] == 6)
                            {
                                stringPackets += "(ARP)";
                                ARP++;
                            }

                            else
                            {
                                stringPackets += "(Unknown)";
                            }

                        }

                        else if (data[12] == 134)
                        {
                            if (data[13] == 221)
                            {
                                stringPackets += "(IPv6)";
                                IPv6++;
                            }

                            else
                            {
                                stringPackets += "(Unknown)";
                            }
                        }
                        else
                        {
                            stringPackets += "(Unknown)";
                        }
                        break;

                    
                    case 24: if (data[12] == 8 && data[13] == 0)
                        {
                            if (data[23] == 1)
                            {
                                stringPackets += "(ICMP)";
                                icmp++;
                            }

                            else if (data[23] == 6)
                            {
                                stringPackets += "(TCP)";
                                tcp++;
                            }

                            else if (data[23] == 17)
                            {
                                udp++;
                                stringPackets += "(UDP)";
                            }

                            else
                            {
                                stringPackets += "(Other)";
                                etc++;
                            }
                        }
                        else
                        {

                        }
                        break;
                }

            }


            stringPackets += Environment.NewLine + Environment.NewLine;
            byteCounter = 0;
            stringPackets += "Raw Data" + Environment.NewLine;
            //Process each byte in our captured packet
            foreach (byte b in data)
            {
                //Add the byte to our string (in hexidecimal)
                stringPackets += b.ToString("X2") + " ";
                byteCounter++;

                if (byteCounter == 16)
                {
                    byteCounter = 0;
                    stringPackets += Environment.NewLine;
                }

            }
            stringPackets += Environment.NewLine;
            stringPackets += Environment.NewLine;
        } //End device_OnPacketArrival


        //**********Starting and stopping the packet capturing
        public void btnStartStop_Click(object sender, EventArgs e)
        {
            
            try
            {
                if (btnStartStop.Text == "Start")
                {
                    
                    btnStartStop.Text = "Stop";
                    device.StartCapture();
                    timer1.Enabled = true;
                    
                    
                    
                  }
                else
                {
                    btnStartStop.Text = "Start";
                    device.StopCapture();
                    timer1.Enabled = false;
                    device.StopCapture();
                    f2.timer2.Enabled = false;
                   
                }
               
            }
            catch (Exception exp) { MessageBox.Show("Error starting and stopping capture"); }
 
        } //End btnStartStop


        //**********Dumping the packet data from stringPackets to the text box1
        public void timer1_Tick(object sender, EventArgs e)
        {
            txtCapturedData.AppendText(stringPackets);
            stringPackets = "";
    
        } //End timer1


        //**********Changing devices
        private void cmbDevices_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (device != null) device.Close();
            device = devices[cmbDevices.SelectedIndex];
            cmbDevices.Text = device.Description;
            txtGUID.Text = device.Name;

            //Register our handler function to the 'packet arrival' event
            device.OnPacketArrival += new SharpPcap.PacketArrivalEventHandler(device_OnPacketArrival);

            //Open the device for capturing
            int readTimeoutMilliseconds = 1000;
            device.Open(DeviceMode.Promiscuous, readTimeoutMilliseconds);
        } //End cmbDevices_SelectedIndexChanged

 
        //**********Saving the file
        private void saveToolStripMenuItem_Click(object sender, EventArgs e)
        {
            saveFileDialog1.Filter = "Text Files|*.txt|All Files|*.*";
            saveFileDialog1.Title = "Save the Captured Packets";
            saveFileDialog1.ShowDialog();

            //Check to see if a filename was given
            if (saveFileDialog1.FileName != "")
            {
                System.IO.File.WriteAllText(saveFileDialog1.FileName, txtCapturedData.Text);
            }
        } //End saveToolStripMenuItem_Click


        //**********Openning the file
        private void openToolStripMenuItem_Click(object sender, EventArgs e)
        {
            openFileDialog1.Filter = "Text Files|*.txt|All Files|*.*";
            openFileDialog1.Title = "Open Captured Packets";
            openFileDialog1.ShowDialog();

            //Check to see if a filename was given
            if (openFileDialog1.FileName != "")
            {
                txtCapturedData.Text=System.IO.File.ReadAllText(openFileDialog1.FileName);
            }
        } //End openToolStripMenuItem_Click


        //**********Show the send window
        private void sendWindowToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (frmSend.instantiations == 0)
            {
                fSend = new frmSend();  //Creates a new frmSend
                fSend.Show();
            }
        }  //End sendWindowToolStripMenuItem_Click


        //**********Clear the main textbox
        private void clearToolStripMenuItem_Click(object sender, EventArgs e)
        {
            txtCapturedData.Clear();
            numPackets = 0;
            IPv4 = 0;
            ARP = 0;
            unknown = 0;
            udp = 0;
            tcp = 0;
            icmp = 0;
            txtNumPackets.Text = "0";
        }

        public void statsToolStripMenuItem1_Click(object sender, EventArgs e)
        {
                Form2 f2 = new Form2(); //creates new windows form for menu strip
                f2.Show();

                f2.timer2.Enabled = true; //starts tick for timer2 on stats form
                

        }

        private void fileToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }
    }
       
    }